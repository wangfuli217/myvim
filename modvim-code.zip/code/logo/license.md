The `vim-flat-logo.svg` file is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or any later version. This work is distributed in the hope that it will be useful, but without any warranty; without even the implied warranty of merchantability or fitness for a particular purpose. See version 2 and version 3 of the GNU General Public License for more details.

https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
https://www.gnu.org/copyleft/gpl-3.0.html
