# Fresh Project

You are faced with a blank page. Enjoy the freedom!
