Neovim's terminal emulator is cool.
