Run the following commands:

* `mkdir -p ~/.config/nvim`
* `touch ~/.config/nvim/init.vim`

These commands are safe if `init.vim` already exists.
